Rails.application.routes.draw do

  get 'comments/create'

  devise_for :users
  root to: 'home#page'
  get 'home/page'
  resources :questions do
    resources :comments
  end
  	
post 'twilio/voice' => 'twilio#voice'
  
  mount ActionCable.server => '/cable'
  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
end