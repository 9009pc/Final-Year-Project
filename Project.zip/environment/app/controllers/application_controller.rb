class ApplicationController < ActionController::Base
  protect_from_forgery with: :exception
  before_action :authenticate_user!
  protected
  def authorise
    unless User.find_by(id: session[:user_id])
        redirect_to "/users/sign_in", notice:"you are trying to access without permission"
    end
  end
  def index
  end
end
