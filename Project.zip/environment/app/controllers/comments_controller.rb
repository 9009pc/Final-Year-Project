class CommentsController < ApplicationController
    before_action :set_user
    before_action :set_question

  def create
    @question = question.find(params[:question_id])
    @answer = @question.comments.create(comment_params)
    if @answer.save
      redirect_to home_page_path
    #else
    end
  end
  
  def new
    @question = Question.new
  end
  
    private

    def set_post
      @question = User.question.find(params[:question_id])
    end

    def set_user
      @user = User.find(params[:user_id])
    end

   def comment_params
        params.require(:answer).permit(:answer)
   end
end

