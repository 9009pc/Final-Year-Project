class QuestionsController < ApplicationController
  def index
    @question = Question.all.includes(:comments)
  end

  def create
    @question = Question.new(ad_params)
    if @question.save
      redirect_to home_page_path, alert: "Question Submitted successfully."
    else
      redirect_to new_question_url, alert: "Error creating question."
    end
  end

  def new
    @question = Question.new
  end

  def show
    @question = Question.find(params.require(question).permit(:id))
  end

  def edit
    @question = Question.find(params.require(question).permit(:id))
  end
  
  private
  def ad_params
    params.require(:question).permit(:title, :description)
  end
end
