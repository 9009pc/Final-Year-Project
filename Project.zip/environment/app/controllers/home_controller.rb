class HomeController < ApplicationController
  def page
    @messages = Message.all
  end

end
